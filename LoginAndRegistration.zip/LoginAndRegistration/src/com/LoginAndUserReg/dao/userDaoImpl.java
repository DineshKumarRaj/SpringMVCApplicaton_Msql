package com.LoginAndUserReg.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.LoginAndUserReg.model.LoginModel;
import com.LoginAndUserReg.model.UserRegistrationModel;
import com.springsource.tcserver.serviceability.request.DataSource;

@Repository
public class userDaoImpl implements userDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public String LoginValidation(LoginModel userDetails) {
		String query = "Select * from userdetails where email ='" + userDetails.getEmail() + "'and password='"
				+ userDetails.getPassword() + "'";
		
		List<LoginModel> loginuser = jdbcTemplate.query(query, new queryRow());
		
		
		
		return loginuser.size() > 0 ? loginuser.get(0).getEmail() : "Invalid user";

	}

	class queryRow implements RowMapper<LoginModel> {

		@Override
		public LoginModel mapRow(ResultSet rs, int rowNum) throws SQLException {

			LoginModel lm = new LoginModel();
			lm.setEmail(rs.getString("email"));
			lm.setPassword(rs.getString("password"));
			return lm;
		}

	}

	@Override
	public String adduser(UserRegistrationModel adduser) {
		
		String query = "insert into userdetails values(?,?,?,?,?)";
		int n = jdbcTemplate.update(query, new Object[] {adduser.getFirstName(),adduser.getLastName()
				,adduser.getCity(),adduser.getEmail(),adduser.getPassword()});
		
		System.out.println("Rows Affected :"+n);
		
		return n>0?"success":"error";
	}

}
