package com.associatedetails.service;

import org.springframework.stereotype.Service;

import com.associatedetails.model.AssociateDetailsModel;

@Service
public interface AssociateDetailsService {
	
	public AssociateDetailsModel getAllAssociates();

}
