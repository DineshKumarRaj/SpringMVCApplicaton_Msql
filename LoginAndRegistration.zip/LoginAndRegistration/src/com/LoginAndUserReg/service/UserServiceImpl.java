package com.LoginAndUserReg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LoginAndUserReg.dao.userDao;
import com.LoginAndUserReg.model.LoginModel;
import com.LoginAndUserReg.model.UserRegistrationModel;

@Service("userservice")
public class UserServiceImpl implements UserService{

	@Autowired
	userDao userdao;
	
	@Override
	public String LoginValidationService(LoginModel logindata) {		
		
		return userdao.LoginValidation(logindata);
	}

	@Override
	public String Userregistration(UserRegistrationModel adduser) {
				
		return userdao.adduser(adduser);
	}

}
