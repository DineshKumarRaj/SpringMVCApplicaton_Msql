package com.associatedetails.dao;

import org.springframework.stereotype.Repository;

import com.associatedetails.model.AssociateDetailsModel;

@Repository
public interface AssociateDetailsDao {
	
	public AssociateDetailsModel fetchAssociateData();

}
