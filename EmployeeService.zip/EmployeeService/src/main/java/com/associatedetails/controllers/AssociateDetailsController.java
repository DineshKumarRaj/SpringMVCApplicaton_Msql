package com.associatedetails.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.associatedetails.model.AssociateDetailsModel;
import com.associatedetails.service.AssociateDetailsService;

@Controller
public class AssociateDetailsController {

	@Autowired
	AssociateDetailsService assService;
	
@RequestMapping("/allAssociates")

public AssociateDetailsModel getAllAssocaites() {

	return assService.getAllAssociates();
}

}
