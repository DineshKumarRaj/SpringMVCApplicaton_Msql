package com.LoginAndUserReg.dao;

import org.springframework.stereotype.Repository;

import com.LoginAndUserReg.model.LoginModel;
import com.LoginAndUserReg.model.UserRegistrationModel;

@Repository
public interface userDao {
	
	public String LoginValidation(LoginModel logindetails);
	public String adduser(UserRegistrationModel adduser);

}
