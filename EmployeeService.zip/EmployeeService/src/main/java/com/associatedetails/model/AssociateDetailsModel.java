package com.associatedetails.model;


public class AssociateDetailsModel {
	
	int associateId;
	String associateName;
	String associateLocation;
	String associateCat;
	
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getAssociateName() {
		return associateName;
	}
	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}
	public String getAssociateLocation() {
		return associateLocation;
	}
	public void setAssociateLocation(String associateLocation) {
		this.associateLocation = associateLocation;
	}
	public String getAssociateCat() {
		return associateCat;
	}
	public void setAssociateCat(String associateCat) {
		this.associateCat = associateCat;
	}


}
