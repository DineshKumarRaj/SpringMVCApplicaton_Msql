package com.LoginAndUserReg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.LoginAndUserReg.model.LoginModel;
import com.LoginAndUserReg.service.UserService;

@Controller
public class LoginController {

	// @ Qualifier annotation is used to specify which service class to call
	// as there is chance that more than one class can be implemented witht the same
	// service.
	@Autowired
	@Qualifier("userservice")
	UserService userservice;

	@RequestMapping(value = "/")
	public String HomePage() {

		return "index";
	}

	@RequestMapping(value = "/loginPage")
	public String LoginPage(Model m) {

		m.addAttribute("loginDetails", new LoginModel());

		return "Login";

	}

	@RequestMapping(value = "/loginAuthentication")
	public String validate(@ModelAttribute("loginDetails") LoginModel login, ModelMap m) {

		String username = userservice.LoginValidationService(login);
		if (!(username.equalsIgnoreCase("Invalid user"))) {

			m.put("username", username);
			return "Home";

		}

		m.put("message", "Invalid Username or Password");

		return "Login";
	}

}
