package com.LoginAndUserReg.service;

import org.springframework.stereotype.Service;

import com.LoginAndUserReg.model.LoginModel;
import com.LoginAndUserReg.model.UserRegistrationModel;

@Service
public interface UserService {
	
	public String LoginValidationService(LoginModel logindata); 
	public String Userregistration(UserRegistrationModel adduser);

}
