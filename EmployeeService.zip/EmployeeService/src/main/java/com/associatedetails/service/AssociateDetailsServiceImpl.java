package com.associatedetails.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.associatedetails.dao.AssociateDetailsDao;
import com.associatedetails.model.AssociateDetailsModel;

@Service
public class AssociateDetailsServiceImpl implements AssociateDetailsService {

	@Autowired
	AssociateDetailsDao assDao;
	
	@Override
	public AssociateDetailsModel getAllAssociates() {
		
		
		
		return assDao.fetchAssociateData();
	}

}
