package com.LoginAndUserReg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.LoginAndUserReg.model.UserRegistrationModel;
import com.LoginAndUserReg.service.UserService;

@Controller
public class RegistrationController {

	@Autowired
	@Qualifier("userservice")
	UserService userservice;
	
	
	
	@RequestMapping(value = "/userRegistration")
	public String RegistrationPage(Model m) {
		
		m.addAttribute("userDetails", new UserRegistrationModel());
		return "UserRegistration";

	}
	
	@RequestMapping(value="/addUser")
	public String adduser(@ModelAttribute("userDetails") UserRegistrationModel adduser, Model m) {
		
		
		String res = userservice.Userregistration(adduser);
		System.out.println("Response:"+res);
		if(res.equalsIgnoreCase("success")) {
			
			m.addAttribute("message", "User Registered Successfully Login to Continue");
			return "UserRegistration";
			
		}
		m.addAttribute("message", "User Registration Failed");
		return "UserRegistration";
	}
	
}
