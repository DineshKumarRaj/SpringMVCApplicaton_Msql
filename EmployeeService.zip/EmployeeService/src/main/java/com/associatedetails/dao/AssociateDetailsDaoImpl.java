package com.associatedetails.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.associatedetails.model.AssociateDetailsModel;

@Repository
public class AssociateDetailsDaoImpl implements AssociateDetailsDao {

	@Autowired
	AssociateDetailsModel assModel;
	
	@Override
	public AssociateDetailsModel fetchAssociateData() {
		
		assModel.setAssociateId(5024105);
		assModel.setAssociateName("DineshKumar");
		assModel.setAssociateLocation("Georgia");
		assModel.setAssociateCat("Contractor");
		
		
		return assModel;
	}

}
